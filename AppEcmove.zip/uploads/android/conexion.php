<?php
  print_r($_GET);
  print_r($_POST);


 ?>
